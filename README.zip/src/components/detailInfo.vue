<script>
//要显示详细的信息，以及一系列交互操作！<span>发起序聊</>  <span>发起咨询</>
</script>
