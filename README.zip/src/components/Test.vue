<style>

.container{
    position:absolute;
    margin:auto;
    margin-left:50px;
    margin-right:50px;
    margin-top:50px;
    margin-bottom:50px;
}

.test{
    width: 100px;
      height: 100px;
      position: absolute;
      top: 0;
      right: 0;
      left: 0;
      bottom: 0;
      margin: auto;
      background-color: pink;
}
</style>

<template>
    

	<div class="test">正中心的盒子</div>

</template>>